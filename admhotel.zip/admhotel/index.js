function gravarInformacoes()
{
    $.ajax({
        type:"POST",
        url:"admhotel.php",
        data: {
            "nome": document.getElementById("nome").value,
            "telefone": document.getElementById("telefone").value,
            "dataNascimento": document.getElementById("dataNascimento").value,
            "email": document.getElementById("email").value,
            "quarto": document.getElementById("quarto").value,
            "refeicoes": document.getElementById("refeicoes").value,
            "nome1": document.getElementById("nome1").value,
            "nome2": document.getElementById("nome2").value,
            "nome3": document.getElementById("nome3").value,
            "dataNascimento1": document.getElementById("dataNascimento1").value,
            "dataNascimento2": document.getElementById("dataNascimento2").value,
            "dataNascimento3": document.getElementById("dataNascimento3").value,
            "telefone1": document.getElementById("telefone1").value,
            "telefone2": document.getElementById("telefone2").value,
            "telefone3": document.getElementById("telefone3").value,
            "nomeCartao": document.getElementById("nomeCartao").value,
            "numero": document.getElementById("numero").value,
            "cvv": document.getElementById("cvv").value,
            "validade": document.getElementById("validade").value        
        }
    });
}
function listar(){
    $.ajax({
        type:"GET",
        dataType:"json",
        url:"print.php",
        function(resultado,resultado2,resultado3){
           echo.log(resultado);
           echo.log(resultado2);
           echo.log(resultado3);
        }
    });
}