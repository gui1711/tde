<?php
    
    $conexao = mysqli_connect("localhost","root","root","pessoal");

    $resultado = mysqli_query($conexao,"SELECT * FROM admhotel");

    $linha = mysqli_fetch_assoc($resultado);

    $resultado2 = mysqli_query($conexao,"SELECT * FROM acompanhantes");

    $linha2 = mysqli_fetch_assoc($resultado2);

    $resultado3 = mysqli_query($conexao,"SELECT * FROM pagamento");

    $linha3 = mysqli_fetch_assoc($resultado3);


    if (($resultado) AND ($resultado->num_rows != 0)) {

        echo "Nome: ".$linha['nome']."<br>";

        echo "Telefone: ".$linha['telefone']."<br>";

        echo "Data de Nascimento: ".$linha['dataNascimento']."<br>";

        echo "Email: ".$linha['email']."<br>";

        echo "Quarto: ".$linha['quarto']."<br>";

        echo "Refeições: ".$linha['refeicoes']."<br>";

    }


    if (($resultado2) AND ($resultado2->num_rows != 0)) {

        echo "Nome do Acompanhante 1: ".$linha2['nome1']."<br>";
    
        echo "Data de Nascimento: ".$linha2['dataNascimento1']."<br>";
    
        echo "Telefone: ".$linha2['telefone1']."<br>";
    
        echo "Nome do Acompanhante 2: ".$linha2['nome2']."<br>";
    
        echo "Data de Nascimento: ".$linha2['dataNascimento2']."<br>";

        echo "Telefone: ".$linha2['telefone2']."<br>";
    
        echo "Nome do Acompanhante 3: ".$linha2['nome3']."<br>";

        echo "Data de Nascimento: ".$linha2['dataNascimento3']."<br>";

        echo "Telefone: ".$linha2['telefone3']."<br>";
    
    }

    if (($resultado3) AND ($resultado3->num_rows != 0)) {

        echo "Nome no Cartão: ".$linha3['nomeCartao']."<br>";

        echo "Número do Cartão: ".$linha3['numero']."<br>";

        echo "CVV: ".$linha3['cvv']."<br>";

        echo "Validade: ".$linha3['validade']."<br>";

    }

?>
