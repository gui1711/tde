<?php

    $nome= $_POST['nome'] ;
    $telefone= $_POST['telefone'] ;
    $dataNascimento= $_POST['dataNascimento'] ;
    $email= $_POST['email'] ;
    $quarto= $_POST['quarto'] ;
    $refeicoes= $_POST['refeicoes'] ;
    $nome1= $_POST['nome1'] ;
    $nome2= $_POST['nome2'] ;
    $nome3= $_POST['nome3'] ;
    $dataNascimento1= $_POST['dataNascimento1'] ;
    $dataNascimento2= $_POST['dataNascimento2'] ;
    $dataNascimento3= $_POST['dataNascimento3'] ;
    $telefone1= $_POST['telefone1'] ;
    $telefone2= $_POST['telefone2'] ;
    $telefone3= $_POST['telefone3'] ;
    $nomeCartao= $_POST['nomeCartao'] ;
    $numero= $_POST['numero'] ;
    $cvv= $_POST['cvv'] ;
    $validade= $_POST['validade'] ;


    $conexao = mysqli_connect("localhost","root","root","pessoal");


    mysqli_query($conexao,"INSERT INTO admhotel(nome,telefone,datanascimento,email,quarto,refeicoes) VALUES('$nome','$telefone','$dataNascimento','$email',$quarto,'$refeicoes')");

    mysqli_query($conexao,"INSERT INTO acompanhantes(nome1,nome2,nome3,dataNascimento1,dataNascimento2,dataNascimento3,telefone1,telefone2,telefone3) VALUES('$nome1','$nome2','$nome3','$dataNascimento1','$dataNascimento2','$dataNascimento3','$telefone1','$telefone2','$telefone3')");

    mysqli_query($conexao,"INSERT INTO pagamento(nomeCartao,numero,cvv,validade) VALUES('$nomeCartao','$numero','$cvv','$validade')");

    