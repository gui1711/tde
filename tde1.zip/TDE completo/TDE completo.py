comecar = (input("Digite INICIAR para começar o jogo: "))
print("====" * 20)

print('''Em um dia normal na Fenda do Biquíni, a cidade está quieta e tranquila quando de repente, é
ouvido gritos desesperados do Bob Esponja procurando seu caracol, Gary. Ao tentar entender o que
aconteceu, os cidadãos foram ao encontro de Bob. Ele revela que seu animal de estimação sumiu e que
não está em nenhum lugar da cidade. Todos ficam preocupados com a notícia e deduzem que foi um
sequestro, já que este fato está cada vez mais frequente na Fenda do Biquíni. Assim sendo, um detetive
chega à cidade para investigar o acontecimento e não descarta nenhum suspeito. Então, ele interroga as
pessoas mais próximas de Bob Esponja, incluindo ele mesmo. Após interrogar todos os suspeitos, ele
descobre as seguintes dicas:''')

print("====" * 20)
if comecar.lower() == "iniciar":
    numero = 1

    while numero == 1:
        numero = int(input("Digite 1 para receber dicas: "))
        print("====" * 20)

        if numero == 1:
            dicas = int(input("Digite qual você deseja de 1 até 11: "))
            print("====" * 20)

            if dicas == 1:
                print("Sandy Bochechas disse que estava no Texas quando Gary sumiu.")  # (Pista não leva a nada)
                print("====" * 20)

            elif dicas == 2:
                print(": Bob não teria nenhum motivo para sumir com Gary, pois o ama.")# (Pista não leva a nada)
                print("====" * 20)

            elif dicas == 3:
                print("Plankton revela que não possui mais nenhum plano malvado contra Bob Esponja e Sirigueijo,""\n"
                      '''pois ouvir falar que Sirigueijo está falido e sabe que ele está sofrendo pois ama dinheiro.''')
                print("====" * 20)

            elif dicas == 4:
                print("Lula Molusco rebate testemunho de Plankton e diz que Siri Cascudo está indo muito bem.")# (Pista não leva a nada)
                print("====" * 20)

            elif dicas == 5:
                print("Se Siri Cascudo está indo bem, Sirigueijo não está falido.")
                print("====" * 20)

            elif dicas == 6:
                print("Quando Patrick foi interrogado, a estrela-do-mar ficou 6 horas pensando em uma resposta e,""\n"'''ao
responder, disse que está com fome e foi embora para sua casa comer''')# (Pista não leva a nada)
                print("====" * 20)

            elif dicas == 7:
                print("Uma fonte anônima revelou que o sequestro de caracóis é uma atividade muito lucrativa.")
                print("====" * 20)

            elif dicas == 8:
                print("Em uma nova interrogação de Plankton, ele fala que Lula Molusco não gostava de Gary.")
                print("====" * 20)

            elif dicas == 9:
                print("Após ser interrogado novamente,""\n"'''Lula Molusco diz que estava ocupado em um chá da tarde com
Bob Esponja no dia que Gary foi sequestrado''')
                print("====" * 20)

            elif dicas == 10:
                print(
                    "Filha de Sirigueijo é interrogada e fala que seu pai está chegando em casa muito triste e desanimado.")
                print("====" * 20)

            elif dicas == 11:
                print("Após investigação, é revelado que Siri Cascudo está sem clientela há algum tempo")
                print("====" * 20)

        if numero != 1:
            print("Você digitou um número inválido")
        numero = int(input("Digite 1 para receber mais dicas e 2 para ariscar um resultado: "))
print("====" * 20)

if numero == 2:
    resultado = input("Quem foi o culpado: ")
    print("====" * 20)

    if resultado.lower() == "sirigueijo" or "lula molusco":
        print("Você acertou 1/2")
        print("====" * 20)

    resultado2 = input("Você acha que tem mais uma pessoa culpada nessa história? ")
    print("====" * 20)

    if resultado2.lower() == "sim":
        print("Você acertou em achar que há mais um personagem envolvido")
        resultado3 = input("Quem você acha que foi esse personagem? ")
        print("====" * 20)

        if resultado3.lower() == "sirigueijo" or "lula molusco":
            print("Você acertou a história por completo")
            print("====" * 20)

print('''Sirigueijo e Lula Molusco são os culpados. Ao ver que o Siri Cascudo está prestes a falir,
Sirigueijo começa a pensar em outros meios de ganhar dinheiro, pois não consegue viver sem. Ao
descobrir que o reino de Atlântida compra caracóis clandestinamente para usar sua gosma como
produto de beleza (gosma de caracol deixa a pele brilhando), Sirigueijo decide entrar nesse mercado e
sabia exatamente onde teria um caracol perfeito para o trabalho. Para isso, foi atrás de Lula Molusco e
contou seu plano, pois sabia que Lula Molusco não gostava de Bob e seu caracol. Então, Lula Molusco
decide ajudar e, no grande dia do sequestro, distraiu Bob Esponja com um convite para um chá da tarde.
Com isso, Sirigueijo invadiu a casa em formato de abacaxi e sequestrou Gary. Felizmente, a polícia
aquática descobriu que Sirigueijo estava escondendo Gary no Siri Cascudo até que os vassalos do reino
de Atlântida recolhessem Gary disfarçadamente. Assim, Lula Molusco e Sirigueijo foram presos e Gary
devolvido a Bob. Mais um dia feliz na Fenda do Biquíni.''')