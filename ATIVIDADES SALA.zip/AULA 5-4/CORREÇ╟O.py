binario = input("Digite um número binário: ")
tamanho = len(binario)

soma = 0

for i in binario:
    tamanho = tamanho - 1
    if i == '1' :
        aux = (int(i)) * (2**tamanho)
        soma = soma + aux

    elif i == '0' :
        aux = 0
        soma = soma + aux

    else:
        soma = "numero inválido"
    break

print(soma)