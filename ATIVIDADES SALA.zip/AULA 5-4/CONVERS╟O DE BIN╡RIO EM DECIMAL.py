binario = input("Digite um valor Binário: ")
tamanho = len(binario)
print (tamanho)

for i in binario:
    print(i)
    