distanciaPercorrida = int(input("Digite a distância percorrida: "))
volumeCombustível = int(input("Digite o volume de combustível: "))

formula = distanciaPercorrida / volumeCombustível

print("a distância percorrida é: ",distanciaPercorrida)
print("o volume de combustível é: ",volumeCombustível)
print("a média é:",formula,"Km/L")