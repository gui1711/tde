numero = int(input("Digite um numero: "))
antecessor = numero - 1
sucessor = numero + 1
print("o antecessor de",numero,"é",antecessor)
print("o sucessor de",numero,"é",sucessor)
