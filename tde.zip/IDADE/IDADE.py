nome = input("Digite seu nome: ")
anoNascimento = int(input("Digite o ano de seu nascimento: "))
anoAtual = int(input("Digite o ano atual: "))

formula = anoAtual - anoNascimento

print("Seu nome é: ",nome)
print("a idade de",nome,"no ano de",anoAtual,"é:",formula)