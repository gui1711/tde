alturaCilindro = float(input("Digite a altura do cilindro: "))
raioCilindro = float(input("Digite o raio do cilindro: "))

formulaArea = 2 * ((raioCilindro*raioCilindro) * 3.14) + (3.14*alturaCilindro*raioCilindro)
formulaLatas = (formulaArea / 3) / 5
formulaValor = formulaLatas * 50

print("quantidade de latas: ",formulaLatas)
print("o valor gasto é:","R$",formulaValor)