nome = input("Digite seu nome: ")
salarioProfissional = int(input("Digite seu salário: "))
salarioMinimo = int(input("Digite o salario minimo vigente: "))

formula = salarioProfissional / salarioMinimo

if salarioMinimo / salarioProfissional > 1:
    print("seu salário é menor que 1 salário Minímo")
else:
    print("Seu nome é",nome)
    if salarioMinimo / salarioProfissional == 1:
         print(nome,"recebe",formula,"salário minímo")
    else:
        print(nome,"recebe",formula,"salários minímos")
