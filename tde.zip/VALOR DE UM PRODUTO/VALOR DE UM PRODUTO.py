nomeProduto = input("Digite o nome do produto: ")
valorProduto = float(input("Digite o valor do produto: "))

formulaValorAvista = valorProduto * 0.95
formulaValorEm2x = valorProduto / 2
formulaValor3 = (valorProduto * 1.05) / 3

print("o nome do produto é: ",nomeProduto)
print("o valor a vista com 5% de desconto é: ",formulaValorAvista)
print("o valor em 2x é: ",formulaValorEm2x)
print("o valor em 3x com acréscimo de 5% é: ",formulaValor3)