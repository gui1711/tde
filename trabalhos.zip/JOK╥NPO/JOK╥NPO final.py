from random import randint

lista = ("Pedra", "Papel", "Tesoura")

contadorPontosJogador1 = 0
contadorPontosJogador2 = 0

modoJogo = int(input('''Escolha uma opção de Jogo:

0 - Humano x Humano
1 - Humano x Computador
2 - Computador x Computador

Digite sua escolha: ''')) #Nesta parte o jogardor escolhe a modalide de jogo

jogar_novamente = "sim" # Variável que define se o jogo continua ou não

while jogar_novamente.lower() == "sim":
    # O código só ira funcionar se a variável for igual a "Sim"

    computador = randint(0, 2) #Randomização das escolhas da maquina

    if modoJogo == 0:
    #Primeira modalidade de jogo, Humano x Humano
        print("-=" * 23)
        print("Você escolheu o modo Humano x Humano")
        print("-=" * 23)
        jogador1 = int(input("Jogador1, digite [0]Pedra, [1]Papel ou [2]Tesoura: "))
        jogador2 = int(input("Jogador2, digite [0]Pedra, [1]Papel ou [2]Tesoura: "))
        print("-=" * 23)
        #Input das opções escolhidas pelos jogadores

        if jogador1 == 0:
            # Se jogador 1 escolher pedra
            if jogador2 == 0:
                # jogador 2 escolher pedra, print "Empate"
                print("Empate!")
            elif jogador2 == 1:
                # jogador 2 escolher papel, print "Jogador 2 venceu"
                print("Jogador 2 venceu")
                contadorPontosJogador2 = contadorPontosJogador2 + 1
            else:
                # jogador 2 escolher tesoura, print "Jogador 1 venceu"
                print("Jogador 1 venceu")
                contadorPontosJogador1 = contadorPontosJogador1 + 1
            print("-=" * 23)
            print("Jogador 1 fez", contadorPontosJogador1, "pontos ; Jogador 2 fez", contadorPontosJogador2, "pontos")
            # Mostra o placar de pontos feitos nas partidas

        elif jogador1 == 1:
            # Se jogador 1 escolher papel
            if jogador2 == 0:
                # jogador 2 escolher pedra, print "Jogador 1 venceu"
                print("Jogador 1 venceu")
                contadorPontosJogador1 = contadorPontosJogador1 + 1
            elif jogador2 == 1:
                # jogador 2 escolher papel, print "Empate"
                print("Empate!")
            else:
                # jogador 2 escolher tesoura, print "Jogador 2 venceu"
                print("Jogador 2 venceu")
                contadorPontosJogador2 = contadorPontosJogador2 + 1
            print("-=" * 23)
            print("Jogador 1 fez", contadorPontosJogador1, "pontos ; Jogador 2 fez", contadorPontosJogador2,"pontos")
            # Mostra o placar de pontos feitos nas partidas

        else:
            # Se jogador 1 escolher tesoura
            if jogador2 == 0:
                # jogador 2 escolher pedra, print "Jogador 2 venceu"
                print("Jogador 2 venceu")
                contadorPontosJogador2 = contadorPontosJogador2 + 1
            elif jogador2 == 1:
                # jogador 2 escolher papel, print "Jogador 1 venceu"
                print("Jogador 1 venceu")
                contadorPontosJogador1 = contadorPontosJogador1 + 1
            else:
                # jogador 2 escolher tesoura, print "Empate"
                print("Empate!")
            print("-=" * 23)
            print("Jogador 1 fez", contadorPontosJogador1, "pontos ; Jogador 2 fez", contadorPontosJogador2, "pontos")
            # Mostra o placar de pontos feitos nas partidas

    elif modoJogo == 1:
    #Segunda modalidade de jogo, Humano x Computador
        print("-=" * 23)
        print("Você escolheu o modo Humano x Computador")
        print("-=" * 23)
        perguntar = int(input('''Escolha uma opção para se jogar:

0 - Pedra
1 - Papel
2 - Tesoura

Digite sua escolha: '''))
#Input das opção escolhida pelo jogador
        print("-=" * 23)
        print("O Jogador 1 escolheu: {}".format(lista[perguntar]))
        print("O Jogador 2 escolheu: {}".format(lista[computador]))
        #Mostra a escolha que o jogador 1 escolheu, e a do jogador 2(Computador)

        print("-=" * 23)
        if computador == 0:
        #Se computador escolher pedra
            if perguntar == 0:
            #jogador 1 escolher pedra, print "Empate"
                print("Empate!")
            elif perguntar == 1:
            #jogador 1 escolher papel, print "Jogador 1 venceu"
                print("Jogador 1 venceu")
                contadorPontosJogador1 = contadorPontosJogador1 + 1
            else:
            #jogador 1 escolher tesoura, print "Jogador 2 venceu"
                print("Jogador 2 venceu")
                contadorPontosJogador2 = contadorPontosJogador2 + 1
            print("-=" * 23)
            print("Jogador 1 fez", contadorPontosJogador1, "pontos ; Jogador 2 fez", contadorPontosJogador2, "pontos")
            # Mostra o placar de pontos feitos nas partidas

        elif computador == 1:
        #Se computador escolher papel
            if perguntar == 0:
            #jogador 1 escolher pedra, print "Jogador 2 venceu"
                print("Jogador 2 venceu")
                contadorPontosJogador2 = contadorPontosJogador2 + 1
            elif perguntar == 1:
            #jogador 1 escolher papel, print "Empate"
                print("Empate!")
            else:
            #jogador 1 escolher tesoura, print "Jogador 1 venceu"
                print("Jogador 1 venceu")
                contadorPontosJogador1 = contadorPontosJogador1 + 1
            print("-=" * 23)
            print("Jogador 1 fez", contadorPontosJogador1, "pontos ; Jogador 2 fez", contadorPontosJogador2, "pontos")
            # Mostra o placar de pontos feitos nas partidas

        else:
        #Se computador escolher tesoura
            if perguntar == 0:
            #jogador 1 escolher pedra, print "Jogador 1 venceu"
                print("Jogador 1 venceu")
                contadorPontosJogador1 = contadorPontosJogador1 + 1
            elif perguntar == 1:
            #jogador 1 escolher papel, print "Jogador 2 venceu"
                print("Jogador 2 venceu")
                contadorPontosJogador2 = contadorPontosJogador2 + 1
            else:
            #jogador 1 escolher tesoura, print "Empate"
                print("Empate!")
            print("-=" * 23)
            print("Jogador 1 fez", contadorPontosJogador1, "pontos ; Jogador 2 fez", contadorPontosJogador2, "pontos")
            # Mostra o placar de pontos feitos nas partidas

    elif modoJogo == 2:
    #Terceira modalidade de jogo, Computador x Computador
        computador2 = randint (0, 2) #Randomização da segunda escolhas da maquina
        print("-=" * 23)
        print("Você escolheu o modo Computador x Computador")
        print("-=" * 23)
        print("O Jogador 1 escolheu: {}".format(lista[computador]))
        print("O Jogador 2 escolheu: {}".format(lista[computador2]))
        print("-=" * 23)
        #Mostra a escolha que o jogador 1(Computador) escolheu e a do jogador 2(Computador)

        if computador == 0:
        #Se computador escolher pedra
            if computador2 == 0:
            #computador 2 escolher pedra, print "Empate"
                print("Empate!")
            elif computador2 == 1:
            #computador 2 escolher papel, print "Jogador 2 venceu"
                print("Jogador 2 venceu")
                contadorPontosJogador2 = contadorPontosJogador2 + 1
            else:
            #computador 2 escolher tesoura, print "Jogador 1 venceu"
                print("Jogador 1 venceu")
                contadorPontosJogador1 = contadorPontosJogador1 + 1
            print("-=" * 23)
            print("Jogador 1 fez", contadorPontosJogador1, "pontos ; Jogador 2 fez", contadorPontosJogador2, "pontos")
            # Mostra o placar de pontos feitos nas partidas

        elif computador == 1:
        #Se computador escolher papel
            if computador2 == 0:
            #computador 2 escolher pedra, print "Jogador 1 venceu"
                print("Jogador 1 venceu")
                contadorPontosJogador1 = contadorPontosJogador1 + 1
            elif computador2 == 1:
             #computador 2 escolher papel, print "Empate"
                print("Empate!")
            else:
            #computador 2 escolher tesoura, print "Jogador 2 venceu"
                print("Jogador 2 venceu")
                contadorPontosJogador2 = contadorPontosJogador2 + 1
            print("-=" * 23)
            print("Jogador 1 fez", contadorPontosJogador1, "pontos ; Jogador 2 fez", contadorPontosJogador2, "pontos")
            # Mostra o placar de pontos feitos nas partidas

        else:
        #Se computador escolher tesoura
            if computador2 == 0:
            #computador 2 escolher pedra, print "Jogador 2 venceu"
                print("Jogador 2 venceu")
                contadorPontosJogador2 = contadorPontosJogador2 + 1
            elif computador2 == 1:
            #computador 2 escolher papel, print "Jogador 1 venceu"
                print("Jogador 1 venceu")
                contadorPontosJogador1 = contadorPontosJogador1 + 1
            elif computador2 == 2:
            #computador 2 escolher tesoura, print "Empate"
                print("Empate!")
            print("-=" * 23)
            print("Jogador 1 fez", contadorPontosJogador1, "pontos ; Jogador 2 fez", contadorPontosJogador2, "pontos")
            # Mostra o placar de pontos feitos nas partidas1


    else:
    #Caso o Jogador digite um valor inválido de modo de jogo
        print("Digite um valor de jogo válido, Tente novamente")
        variavelSaida = exit()

    print("-=" * 23)
    jogar_novamente = input("Você quer tentar novamente? Digite Sim ou Não: ") #Input de continuar ou sair

print("-=" * 23)
print('''Placar Geral:
    Jogador 1 fez''', contadorPontosJogador1, '''pontos                         
    Jogador 2 fez''', contadorPontosJogador2,'''pontos''')
print("-=" * 23)
#Mostra o placar de pontos feitos nas partidas
print('''Obrigado por jogar, Até a próxima!
Desenvolvido por Guilherme Daudt''')
#Mostra os agradecimentos e o nome do aluno responsável pelo código
print("-=" * 23)