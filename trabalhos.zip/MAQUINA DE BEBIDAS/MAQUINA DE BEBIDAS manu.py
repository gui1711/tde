import math


def printMatriz(matriz):
    for vector in matriz:
        print(vector)


# Função para fazer print do estoque

def inventorySub(matriz, line, numberBought):
    newAmount = matriz[line - 1][3] - numberBought
    matriz[line - 1][3] = newAmount


# Função para ajustar o estoque

def specificChange(totalChange):
    list = 0
    moneyBills = [200, 100, 50, 20, 10, 5, 2, 1, 0.5, 0.25, 0.10, 0.5, 0.01]
    for i in range(13):
        numberBills = totalChange / moneyBills[i]
        rounded = math.floor(numberBills)
        if rounded >= 1:
            totalChange = totalChange - (rounded * moneyBills[i])
            list = list + 1
            print(list, "-", rounded, "nota de", moneyBills[i])


# Função para calcular as notas de troco

inventory = [[1, "Coca cola", 3.75, 2], [2, "Pepsi", 3.67, 5], [3, "Monster", 9.96, 1], [4, "Café", 1.25, 100],
             [5, "Redbull", 13.99, 2]]
# Matriz do estoque

printMatriz(inventory)
# Comando para fazer print do estoque

totalInventory = 110
while totalInventory > 0:
    order = int(input("Type in the code of the beverage of your choice:"))
    amount = int(input("How many would you like?"))
    # Pedido

    if 6 <= order <= 0:
        print("Invalid code, please re-enter your order.")
        printMatriz(inventory)
        # "If" para quando a pessoa digita um código que não existe.

    if amount > inventory[order - 1][3]:
        print("That amount is not available. The number available of that beverage is:", inventory[order - 1][3],
              "Please re-enter your order.")
        printMatriz(inventory)
        # "If" para quando a pessoa pede mais do que está disponível.

    else:
        totalInventory = totalInventory - amount
        inventorySub(inventory, order, amount)
        # Ajuste do estoque total e da bebida pedida específicamente

        print("Selected:", inventory[order - 1][1])
        print("That will cost R$", (inventory[order - 1][2] * amount))
        payment = float(input("How much would you like to pay with?"))
        # Variável de quanto a pessoa vai pagar

        change = payment - (inventory[order - 1][2] * amount)
        print("Your total change is R$", change)
        specificChange(change)
        # Definição do troco

        print("Thank you for your order!")
        print("------------------------------------------------------")
        print("------------------------------------------------------")
        printMatriz(inventory)
        # Finalização