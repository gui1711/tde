import math


def printMatriz(matriz):
    for vetor in matriz:
        print(vetor)
    # Função que faz um print dos vetores dentro da matriz


def controleInventario(matriz, linha, numeroEscolhido,troco):
    if troco < 0:
        print("O valor digitado é inferior ao preço do produto,","\n"
"Faça sua escolha novamente e digite um valor maior ou igual ao preço do produto")
    else:
        novoEstoque = matriz[linha - 1][3] - numeroEscolhido
        matriz[linha - 1][3] = novoEstoque
    # Função para regular o estoque da matriz


def pagamento(troco):
    controle = 0
    dinheiro = [200, 100, 50, 20, 10, 5, 2, 1, 0.5, 0.25, 0.10, 0.05, 0.01]
    for i in range(13):
        numeroContas = troco / dinheiro[i]
        formulaArredondamento = math.floor(numeroContas)
        if formulaArredondamento >= 1:
            troco = troco - (formulaArredondamento * dinheiro[i])
            controle += 1
            print(controle, "-->", formulaArredondamento, "nota de", dinheiro[i])
    # Função que calcula o troco


matriz = [[1, 'Coca-Cola', 3.75, 2], [2, 'Pepsi    ', 3.67, 5], [3, 'Monster  ', 9.96, 1], [4, 'Café     ', 1.25, 100],
          [5, 'Redbull  ', 13.99, 2]]
# Matriz que define os produtos, os preços e estoques
print("[ID, Produto, Preço, Estoque]")

printMatriz(matriz)
print("==" * 20)

estoqueTotal = (matriz[0][3] + matriz[1][3] + matriz[2][3] + matriz[3][3] + matriz[4][3])
while estoqueTotal > 0: # Loop para fazer o pedido
    escolha = int(input("Digite o ID que você deseja: ")) # O usuário escolhe o que ele quer
    if escolha <= 0 or escolha >= 6: # condição que verifica se o ID digitado é válido
        print("o Id que você digitou é inválido, tente novamente")
        print("==" * 20)
        printMatriz(matriz)
        print("==" * 20)
        escolha = int(input("Digite um valor de ID que você deseja novamente: "))
        print("==" * 20)

    quantidade = int(input("Digite a QUANTIDADE que você deseja: "))
    # O usuário escolha a quantidade do produto que ele deseja
    if quantidade > matriz[escolha - 1][3]:
        print("a quantidade desejada não está disponível no momento,","\n"
        "a quantidade do produto disponível em estoque é", matriz[escolha - 1][3],", Redigite a sua quantidade")
        print("==" * 20)
        printMatriz(matriz)
        print("==" * 20)
        # Codição para caso a pessoa queira uma quantidade inválida do produto

    else:
        print("==" * 20)
        print("O produto que você escolheu é:", matriz[escolha - 1][1])
        print("E isto irá custar: R$", matriz[escolha - 1][2] * quantidade)
        print("==" * 20)
        pagamentoRecebido = float(input("Digite com quanto você gostaria de pagar: "))
        # Variável do valor recebido para fazer pagamento

        troco = pagamentoRecebido - (matriz[escolha - 1][2] * quantidade)
        print("O total do seu pedido é: R$", troco)
        pagamento(troco)
        print("==" * 20)
        # Define o troco a ser recebido

        estoqueTotal -= quantidade
        controleInventario(matriz, escolha, quantidade,troco)
        print("==" * 20)
        # faz o ajuste de estoque do produto escolhido

        print('''Obrigado por fazer seu pedido, Até a próxima!
Desenvolvido por Guilherme Daudt!''')
        # Mostra os agradecimentos e o nome do aluno responsável pelo código
        print("==" * 20)
        printMatriz(matriz)
        print("==" * 20)